package com.example.logginvalorant.Moduls;

public class Map {
    private String name;

    public Map(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}

